/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coursework;


import java.awt.Font;
import java.awt.event.ActionListener;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JMenuItem;

/**
 *
 * @author sh8088y
 */
public class CommonCode {
    private static final String UK_DATE_FORMAT_NOW ="dd-MM-yyyy HH:mm:ss";
    private String ukDateAndTime;
    private ActionListener calledBy;
    
    
    
    public final String userName = System.getProperty("user.name");
    public final String appDir = System.getProperty("user.dir");
    public final String os = System.getProperty("os.name");
    public final String fileSeparator = System.getProperty("file.separator");
    
    public CommonCode(ActionListener call) {
        calledBy = call;
    }

    CommonCode() {
        
    }
    
//Get Date Time method      
     public String getDateAndTime() {
        
        Calendar cal = Calendar.getInstance();
        SimpleDateFormat ukSDF =new SimpleDateFormat(UK_DATE_FORMAT_NOW);
        ukDateAndTime = ukSDF.format(cal.getTime());
        return ukDateAndTime;
    }


        //Function to create a generic menuItem  
    protected JMenuItem makeMenuItem(String txt, String actionCommand, String toolTipText, Font fnt) {
        JMenuItem mnuItem = new JMenuItem();
        mnuItem.setText(txt);
        mnuItem.setActionCommand(actionCommand);
        mnuItem.setToolTipText(toolTipText);
        mnuItem.setFont(fnt);
        mnuItem.addActionListener(calledBy);
        return mnuItem;
    }

    protected JButton makeButton(String imageName, String actionCommand, String toolTipText, String altText) {
        JButton button = new JButton();
        button.setToolTipText(toolTipText);
        button.setActionCommand(actionCommand);
        button.addActionListener(calledBy);
        String imgLocation = System.getProperty("user.dir") + "\\icons\\" + imageName + ".png";
        File file = new File(imgLocation);
        if (file.exists() && !file.isDirectory()) {
            //Image does exist
            Icon img = new ImageIcon(imgLocation);
            button.setIcon(img);
        } else {
            //image doesn't exist
            button.setText(altText);
            System.err.println("Resource not found: " + imgLocation);
        }
        return button;
    }
 
//code to read from a file
    public ArrayList <String> readTextFile(String fileName){
        ArrayList file = new ArrayList();
        String line;
        
        if((fileName ==null)||(fileName.equals("")))
           System.out.println("No file name specified.");
        else{
            try{
                 BufferedReader in =new BufferedReader(new FileReader(fileName));
                 if(!in.ready())
                      throw new IOException();
                 while((line=in.readLine())!=null){
                     file.add(line);
                 }
                 in.close();
                 
            }catch(IOException e){
                System.out.println(e);
                file.add("File not found");
            }
        }
        return file;
    }
    
 //Code to write in a file   
    public void writeTextFile(String fn, ArrayList<String> outputText)
        throws FileNotFoundException, IOException {
        File fileName= new File(fn);
        Writer output = new BufferedWriter(new FileWriter(fileName));
        try{
            for(int i=0; i<outputText.size();i++)
                output.write(outputText.get(i).toString()+"\n");
            }catch(Exception e){
                System.out.println(e.getMessage());
                throw e;
            }finally{
            output.close();
        }
    }
    
     
        
}


