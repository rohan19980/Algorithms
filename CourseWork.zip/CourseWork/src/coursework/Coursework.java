/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coursework;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import javax.swing.*;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;

/**
 *
 * @author sh8088y
 */
public class Coursework extends JFrame implements ActionListener, KeyListener {

    JPanel pnl = new JPanel(new BorderLayout());
    JTextArea txtNewNote = new JTextArea();
    JTextArea txtDisplayNotes = new JTextArea();
    ArrayList<String> note = new ArrayList<>();
    ArrayList<String> course = new ArrayList<>();
    String crse ="";
    JComboBox courseList = new JComboBox();
    AllNotes allNotes = new AllNotes();
    CommonCode cc = new CommonCode(this);    
    CoursePane cp;
    int noteID;
    
        Font fnt = new Font("Georgia", Font.PLAIN, 24);
        JMenuBar menuBar = new JMenuBar();//Creating a menu bar

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Coursework prg = new Coursework();
        
        
    }

    // Using MVC
    public Coursework() {
        model();
        view();
        controller();
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if ("Course".equals(ae.getActionCommand())) {
            crse=courseList.getSelectedItem().toString();
            System.out.println(crse);
            readAllNotes();
        }
        if ("Close".equals(ae.getActionCommand())) {
          
        }
        if ("Exit".equals(ae.getActionCommand())) {
            System.exit(0);
            writeCourseListToTxtFile();
        }
        if("NewNote".equals(ae.getActionCommand())){
            if(!"".equals(txtNewNote.getText()))
            addNote();
            txtNewNote.setText("");
        }
        if("CourseOptionPane".equals(ae.getActionCommand())){
           cp =new CoursePane(this);
            cp.courseOptionPane(course);
        }        
        if("Save".equals(ae.getActionCommand())){
            course=cp.save();
            makeCourseList();
            writeCourseListToTxtFile();
        }
        if("SaveAll".equals(ae.getActionCommand())){
            saveAll();
        }
    }


//View
    private void view() {
       
 //Process to create the whole menu bar
        
        JMenu note = new JMenu("Note");;//Creating a menu named "Note"
        note.setToolTipText("Note tasks");
        note.setFont(fnt);
        note.add(cc.makeMenuItem("New", "NewNote", "Create a new note.", fnt));
        note.addSeparator();
        note.add(cc.makeMenuItem("Close", "Close", "Clear the current note.", fnt));
        menuBar.add(note);
        
        JMenu courseLst = new JMenu("Course");;//Creating a menu for course
        courseLst.setToolTipText("Course tasks");
        courseLst.setFont(fnt);
        courseLst.add(cc.makeMenuItem("Option panel", "CourseOptionPane", "Create a new course.", fnt));
        menuBar.add(courseLst);
        
        JMenu courseWork = new JMenu("Coursework");;//Creating a menu for coursework
        courseWork.setToolTipText("Coursework options");
        courseWork.setFont(fnt);
        courseWork.add(cc.makeMenuItem("New coursework", "NewCourseWork", "Create a new coursework.", fnt));
        menuBar.add(courseWork);
        
        menuBar.add(cc.makeMenuItem("Exit", "Exit", "Close this program", fnt));
        
            
            
            courseList.setFont(fnt);
            courseList.setMaximumSize(courseList.getPreferredSize());
            courseList.addActionListener(this);
            courseList.setActionCommand("Course");
            
        menuBar.add(courseList);
        
            setJMenuBar(menuBar);
        
//Making the toolBar
        JToolBar toolBar = new JToolBar();
        JButton button = null;
        button = cc.makeButton("Create", "NewNote", "Create a new note", "New");
        toolBar.add(button);
     //
        button = cc.makeButton("closed door", "Close","Close this note","Close");
        toolBar.add(button);
        
     //
        toolBar.addSeparator();
        button = cc.makeButton("exit", "Exit", "Exit from this program.", "Exit");
        toolBar.add(button);
        toolBar.addSeparator();
        
        button=cc.makeButton("Save", "SaveAll", "Save all you have done", "Save");
        toolBar.add(button);
       add(toolBar, BorderLayout.NORTH); 
       
//panel west
        JPanel pnlWest = new JPanel();
        pnlWest.setLayout(new BoxLayout(pnlWest, BoxLayout.Y_AXIS));
        pnlWest.setBorder(BorderFactory.createLineBorder(Color.black));
        txtNewNote.setFont(fnt);
        pnlWest.add(txtNewNote);
        
       //setting up the button to add note
        JButton btnAddNote=new JButton("Add note");
        btnAddNote.setActionCommand("NewNote");
        btnAddNote.addActionListener(this);
        pnlWest.add(btnAddNote);
        add(pnlWest, BorderLayout.SOUTH); //Adding the west panel to the frame
               

        
//Center panel        
        JPanel cen = new JPanel();
        cen.setLayout(new BoxLayout(cen, BoxLayout.Y_AXIS)); 
        cen.setBorder(BorderFactory.createLineBorder(Color.black));
        JScrollPane scrollPane = new JScrollPane(txtDisplayNotes);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setPreferredSize(new Dimension(250, 250));
        txtDisplayNotes.setFont(fnt);
        cen.add(txtDisplayNotes);
        txtDisplayNotes.setLineWrap(true);
        txtDisplayNotes.setEditable(false);
        add(cen, BorderLayout.CENTER);
         
//JFrame settings        
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setTitle("Coursework - Saif Uddin Helal");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true); // Needed to ensure that the items can be seen.
        

        
        
    }

    //Controller
    private void controller() {
       
        readTextFileToCourseList();
        makeCourseList();
        
     
    }

    //Model
    private void model() {

        
//        Note nt= new Note();
//        nt.setNoteID(1);
//        nt.setDate(cc.getDateAndTime());
//        nt.setCourse(crse);
//        nt.setNote("This is a new note. ");
//        allNotes.addANote(nt.getNoteID(), nt.getCourse(), nt.getNote());
//        
//        nt= new Note();
//        nt.setNoteID(1);
//        nt.setDate(cc.getDateAndTime());
//        nt.setCourse(crse);
//        nt.setNote("This is a new note. ");
//        allNotes.addANote(nt.getNoteID(), nt.getCourse(), nt.getNote());
    
    }

    private void readAllNotes() {
         txtDisplayNotes.setText("");
         
        for(Note n : allNotes.getAllNotes()) {
            if(n.getCourse().equals(courseList.getSelectedItem().toString()))
                txtDisplayNotes.append(n.getDate()+"\t"+n.getNote()+"\n");            
        }
        
        
        //txtDisplayNotes.setText(txtNotes);
    }
    
    
    private void addNote(){
        note.add(txtNewNote.getText());
        
        allNotes.addANote(1, courseList.getSelectedItem().toString(), txtNewNote.getText());
        
        readAllNotes();
    }

    
    private void writeCourseListToTxtFile(){
        String path=cc.appDir+"\\Course.txt";
        try{
        cc.writeTextFile(path, course);
        }catch(Exception e){
            System.out.println("Problem! "+path);
        }
        
    }
    
    private void saveAll(){
        
        allNotes.writeAllNotes();
    }
    
    
    private void readTextFileToCourseList(){
        ArrayList <String> readCourse= new ArrayList();
        readCourse=cc.readTextFile(cc.appDir+"\\Course.txt");
        if("File not found".equals(readCourse.get(0))){
            course.add("No course added yet!");
        }
        else{
            course.clear();
            course=readCourse;
        }
        
    }
    
    
    @Override
    public void keyTyped(KeyEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void keyPressed(KeyEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void keyReleased(KeyEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void addNewCourse(String crs){
        course.add(crs);
        
    }
   
    public void makeCourseList(){
      //Course list
        courseList.removeAllItems();
            
        for(String line : course)
            courseList.addItem(line);
    }
    
}
