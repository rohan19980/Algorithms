/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coursework;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JToolBar;

/**
 *
 * @author sh8088y
 */
public class CoursePane extends JFrame implements ActionListener{
    private DefaultListModel crsList=new DefaultListModel();
    private JList list =new JList(crsList);
    private ActionListener calledBy;
    private ArrayList<String> course=new ArrayList();
    private JTextField txt=new JTextField();
    CommonCode cc=new CommonCode(this);
    
    CoursePane(ActionListener cl){
        calledBy=cl;
        
    }
    
    
     public void courseOptionPane(ArrayList<String> cList){
         JPanel panelCenter=new JPanel();
         course=cList;
         
         setTitle("Course list pane");
         
         JButton btn=null;
         JToolBar tb;
         
         tb=new JToolBar();
         btn=cc.makeButton("Add", "AddCourse", "Add a new course to the list", "Add Course");
        tb.add(btn);
        
        tb.add(txt);
       tb.addSeparator();
       
        btn=cc.makeButton("Delete", "DeleteCourse", "Delete a course from the list", "Delete Course");
        tb.add(btn);
        add(panelCenter, BorderLayout.CENTER);
        add(tb,BorderLayout.NORTH);
        makeCourseList();
        panelCenter.setLayout(new BoxLayout(panelCenter, BoxLayout.Y_AXIS)); 
        panelCenter.setBorder(BorderFactory.createLineBorder(Color.black));
        panelCenter.add(list);
        
       
       
       
       
        
        btn=cc.makeButton("Save", "Save", "Save all courses", "Save");
        btn.addActionListener(calledBy);
        tb.add(btn);
        tb= new JToolBar();
        tb.add(btn, BorderLayout.CENTER);
        add(tb, BorderLayout.SOUTH);
       setSize(400, 400);
        
       setVisible(true); // Needed to ensure that the items can be seen. 
        
        
        
      }
      
      public void create(){
          if("No course added yet!".equals(course.get(0)))
              course.remove(0);
          course.add(txt.getText());
          makeCourseList();
      }
      
      public void delete(){
          course.remove(list.getSelectedIndex());
          makeCourseList();
      }
      
      public ArrayList<String> save(){
          
          
          return course;
      }
    
      public void makeCourseList(){
          crsList.clear();
          for(String l : course){
           crsList.addElement(l);
           txt.setText("");
       }
      }
      
      
//      public void courseWorkOptionPane(){
//         JPanel panelCenter=new JPanel();
//         
//         setTitle("Coursework pane");
//         
//         JButton btnAddCourse=new JButton("Add Coursework");
//         btnAddCourse.setActionCommand("AddCourseWork");
//        btnAddCourse.addActionListener(this);
//        
//        JToolBar tb;
//        
//        JButton btnSave=new JButton("------ Save ------");
//        btnSave.setActionCommand("Save");
//        btnSave.addActionListener(calledBy);
//        tb= new JToolBar();
//        tb.add(btnSave, BorderLayout.CENTER);
//        add(tb, BorderLayout.SOUTH);
//        
//        
//        JButton btnDeleteCourse=new JButton("Delete Course");
//        btnDeleteCourse.setActionCommand("DeleteCourse");
//        btnDeleteCourse.addActionListener(this);
//        
//       
//        makeCourseList();
//        
//       tb=new JToolBar();
//       tb.add(btnAddCourse);
//       tb.add(txt);
//       tb.addSeparator();
//       tb.add(btnDeleteCourse);
//       panelCenter.setLayout(new BoxLayout(panelCenter, BoxLayout.Y_AXIS)); 
//        panelCenter.setBorder(BorderFactory.createLineBorder(Color.black));
//        panelCenter.add(list);
//        
//        add(panelCenter, BorderLayout.CENTER);
//       add(tb,BorderLayout.NORTH);
//       setSize(400, 400);
//        
//       setVisible(true); // Needed to ensure that the items can be seen. 
//        
//        
//        
//      }
      

    @Override
    public void actionPerformed(ActionEvent e) {
        if("AddCourse".equals(e.getActionCommand())){
            create();
        }
        if("DeleteCourse".equals(e.getActionCommand())){
            delete();
        }
    }
}
